//
//  ex2.h
//  cg-projects
//
//  Created by HUJI Computer Graphics course staff, 2013.
//

#ifndef __ex2__ex2__
#define __ex2__ex2__

#include <iostream>

#endif /* defined(__ex2__ex2__) */
